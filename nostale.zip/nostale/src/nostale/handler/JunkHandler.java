package nostale.handler;

public class JunkHandler extends Handler{

}
