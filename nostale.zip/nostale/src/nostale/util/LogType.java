package nostale.util;

public enum LogType {
Receive,Send
}
