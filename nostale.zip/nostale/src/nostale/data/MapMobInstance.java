package nostale.data;

import nostale.util.Pos;

public class MapMobInstance extends Mob{
	public int id;
    public short MapId;
    public Pos Pos;
}
