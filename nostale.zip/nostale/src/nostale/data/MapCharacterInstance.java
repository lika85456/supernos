package nostale.data;

import nostale.util.Pos;

public class MapCharacterInstance extends Character{
    public Pos Pos;
    public long id;
}
