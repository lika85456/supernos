package nostale.data;

public class InventoryItemInstance extends Item{
    public int InventoryPos;
    public int Amount;
}
