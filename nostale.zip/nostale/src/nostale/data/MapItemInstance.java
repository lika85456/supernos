package nostale.data;

public class MapItemInstance extends Item{
    public int id;
    public nostale.util.Pos Pos;
    public int Amount;
    public int OwnerID;
}
