package nostale;

public class ServerList
{
    public static Server DE = new Server("79.110.84.75",4001);
    public static Server EN = new Server("79.110.84.75",4000);
    public static Server FR = new Server("79.110.84.75",4002);
    public static Server IT = new Server("79.110.84.75",4003);
    public static Server PL = new Server("79.110.84.75",4004);
    public static Server ES = new Server("79.110.84.75",4005);
    public static Server CZ = new Server("79.110.84.75",4006);
    public static Server RU = new Server("79.110.84.75",4007);
    public static Server TR = new Server("79.110.84.75",4008);
}
