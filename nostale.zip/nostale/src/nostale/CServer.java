package nostale;

//Server ENUM list
public enum CServer
{
    DE, EN, FR, IT, PL, ES, CZ, RU, TR
}